This executable is a c++ program for playing the War card game against the computer. 
This game uses a standard 52 card deck with no jokers.

HOW TO PLAY:
The 52 card deck is shuffled and split evenly into 2 hands, one hand for each player.
For each round, each player draws the top card from their hand and lays the card face up. 
Whichever card ranks highest (2 is lowest, ace is highest) wins that round.
If both cards are the same, 3 more cards are drawn face down and the fourth card is drawn face up to again compare rank.
This continues until there is a winner. The winner takes all the cards used in that round into their discard pile.
Rounds continue until either player runs out of cards in their hand. 
Then that user shuffles their discard pile and uses that as their new hand to continue playing.
The player left with all the cards in the original deck wins the game.

To play the game using this executable, navigate to this folder in the command line and type "War.exe"
